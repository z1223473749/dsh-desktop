import type { ConversationContentProps } from '../contract/slots.ts';
/**
 * Render the shared Conversation body and its occurrence-selected local Components.
 * @param props - Factory input, standard Session sources, and Conversation seats.
 * @returns the Conversation view, Composer, and optional width controls.
 */
export declare function ConversationContent(props: ConversationContentProps): import("react").JSX.Element;
//# sourceMappingURL=ConversationContent.d.ts.map