/** Shared renderer failure categories. @module */
/** Renderer assembly failures that must escape component error boundaries. */
export declare class SlotAssemblyError extends Error {
}
//# sourceMappingURL=errors.d.ts.map