/** Declarative Agent capability sets, activation and session binding. */
import { Context } from '@deepseek-ai/cordis';
import z from '@deepseek-ai/schemastery';
import { TypertRemoteService } from '@deepseek-ai/dsh-typert-protocol';
import { type ScopeKey } from '@deepseek-ai/dsh-scope';
import type { Agent } from '@deepseek-ai/dsh-agent';
import type { AgentPresetDocument, AgentPresetRoster } from './types.ts';
import { type PresetDefinition } from './definition.ts';
import type { AgentPreset, Config } from './preset.ts';
import { type AgentPresetComposition } from './composition-inventory.ts';
export { agentPresetProjectionDefinition } from './session.ts';
export { entryListProblem, type PresetDefinition } from './definition.ts';
export { auditRows, livePresetMounts, leakedServices, serviceForAgent, standingMountFor, type PresetMount, type RowAudit } from './mount.ts';
export type { AgentPreset, Config } from './preset.ts';
declare module '@deepseek-ai/cordis' {
    interface Context {
        agentPresets: AgentPresetRegistry;
    }
}
/** Registry of YAML-declared presets and the revisions live Agents retain. */
export declare class AgentPresetRegistry extends TypertRemoteService {
    config: Config;
    static inject: string[];
    static Config: z<Schemastery.ObjectS<NoInfer<{
        default: z<string, string, "defined">;
        selectedDefault: z<string, string, "volatile">;
        modeSelectionEnabled: z<boolean, boolean, "volatile-defined">;
    }>>, Schemastery.ObjectT<NoInfer<{
        default: z<string, string, "defined">;
        selectedDefault: z<string, string, "volatile">;
        modeSelectionEnabled: z<boolean, boolean, "volatile-defined">;
    }>>, "plain">;
    private readonly owner;
    private readonly definitions;
    private readonly generations;
    private readonly bindings;
    private readonly switches;
    constructor(ctx: Context, config: Config);
    /** Default preset for a subsequently created session. */
    get defaultId(): string;
    private policy;
    /** Register and eagerly load a definition; activation failure remains visible in the roster.
     * @param definition Parsed configuration supplied by the declaring plugin.
     * @returns Definition disposer after activation or its diagnostic settles; the declaring plugin owns it.
     */
    register(definition: PresetDefinition): Promise<() => Promise<void>>;
    private activate;
    /**
     * Current activation diagnostic of a definition.
     *
     * A mount failure is final. A mounted tree is re-audited on every read: a
     * row waiting for a Host service activates by itself once that provider
     * finishes, so the audit waits for the Host Loader tree to settle before
     * reporting the row as unusable. Callers therefore must not run inside a
     * Host row's own activation, which the settlement would wait on.
     * @param record - the definition to audit.
     * @returns one line per unusable row, or undefined when the definition is usable.
     */
    private diagnostic;
    private collect;
    /** Read every declared preset, including activation failures.
     * @returns Display metadata and loading diagnostics.
     */
    list(): Promise<AgentPreset[]>;
    /** Read the selection roster and chooser policy.
     * @returns Current presets, default and chooser policy.
     */
    remoteExportList(): Promise<AgentPresetRoster>;
    /** Resolve an identity without starting an Agent.
     * @param id Explicit preset or the current default.
     * @returns Current metadata, including failure when activation failed.
     */
    resolve(id?: string): Promise<AgentPreset>;
    /** Read one declaration's child plugin list as YAML, for viewing only.
     * @param agentPreset Preset identity.
     * @returns The declared composition beside its published metadata.
     */
    readDocument(agentPreset: string): Promise<AgentPresetDocument>;
    private retain;
    private bind;
    private join;
    /** Bind an unpublished Agent to the current preset revision.
     * @param ctx Agent context from its setup callback.
     * @param id Requested preset, or the default.
     * @returns Bound preset identity.
     */
    mount(ctx: Context, id?: string): Promise<AgentPreset>;
    /** Join a child to the exact revision retained by its parent.
     * @param ctx Child Agent context.
     * @param parent Parent Agent context.
     * @returns Inherited preset id, or undefined in a preset-free composition.
     */
    composeFrom(ctx: Context, parent: Context): string | undefined;
    /** Read the preset a live Agent uses.
     * @param ctx Agent context.
     * @returns Its preset id, if bound.
     */
    composedPreset(ctx: Context): string | undefined;
    /** Read a service supplied inside an Agent's isolated preset group.
     * @param agent Agent whose composition is queried.
     * @param name Cordis service name.
     * @returns The service, or undefined.
     */
    serviceFor<K extends string & keyof Context>(agent: {
        ctx: Context;
    }, name: K): Context[K] | undefined;
    /** Rebind a blank Agent; the caller owns the blank-session check.
     * @param ctx Agent context.
     * @param id Requested preset.
     * @returns The bound identity.
     */
    recompose(ctx: Context, id: string): Promise<AgentPreset>;
    /** Select a preset before a session starts its first turn.
     * @param agent Target Agent.
     * @param agentPreset Requested identity.
     * @returns Committed preset identity.
     */
    select(agent: Agent, agentPreset: string): Promise<string>;
    /** Read current registrations for cold transcript presentation.
     * @param id Preset identity or the default.
     * @returns A revision lease; dispose it after the scoped read completes.
     */
    acquireScope(id?: string): Promise<{
        key: ScopeKey;
    } & AsyncDisposable>;
    /** Read plugin rows without creating an Agent.
     * @returns Current declaration metadata and activation states.
     */
    compositionInventory(): Promise<AgentPresetComposition[]>;
}
export default AgentPresetRegistry;
//# sourceMappingURL=index.d.ts.map