/** Agent Teams Web dictionaries. */
/** Locale namespace owned by the Agent Teams Web UI. */
export declare const NS = "agent-team";
/** Simplified Chinese dictionary and key source. */
export declare const zh: {
    trigger: string;
    loading: string;
    unavailable: string;
    failure: string;
    empty: string;
    roster: string;
    tasks: string;
    model: string;
    open: string;
    current: string;
    owner: string;
    unowned: string;
    blockedBy: string;
    writeScopes: string;
    ready: string;
    blocked: string;
    'task.expand': string;
    'task.collapse': string;
    'memberStatus.running': string;
    'memberStatus.inactive': string;
    'memberStatus.provisioning': string;
    'memberStatus.failed': string;
    'status.pending': string;
    'status.in_progress': string;
    'status.completed': string;
};
/** Agent Teams locale key union. */
export type TeamKey = keyof typeof zh;
/** English dictionary checked against the Chinese key set. */
export declare const en: {
    trigger: string;
    loading: string;
    unavailable: string;
    failure: string;
    empty: string;
    roster: string;
    tasks: string;
    model: string;
    open: string;
    current: string;
    owner: string;
    unowned: string;
    blockedBy: string;
    writeScopes: string;
    ready: string;
    blocked: string;
    'task.expand': string;
    'task.collapse': string;
    'memberStatus.running': string;
    'memberStatus.inactive': string;
    'memberStatus.provisioning': string;
    'memberStatus.failed': string;
    'status.pending': string;
    'status.in_progress': string;
    'status.completed': string;
};
//# sourceMappingURL=locales.d.ts.map