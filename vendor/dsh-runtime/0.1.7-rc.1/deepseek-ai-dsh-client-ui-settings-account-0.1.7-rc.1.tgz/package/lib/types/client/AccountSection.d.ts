import type { AccountDetails, AccountView, SignInAttemptId } from '@deepseek-ai/dsh-deepseek-account/types';
import type { PropsRuntime, PropsLocale, InjectFace, HostObservable } from '@deepseek-ai/dsh-client-ui-slots';
import type { ThemeSnapshot } from '@deepseek-ai/dsh-client-ui-theme/client';
import { type PlatformBridge } from './PlatformOverlay.tsx';
/** Safe account snapshot shared by the settings page and launcher. */
export interface AccountSnapshot {
    /** Latest Host state, absent until the stream responds. */
    view: AccountView | undefined;
    /** Sanitized profile and balance query outcomes, absent while loading. */
    details: Partial<AccountDetails> | undefined;
    /** Whether the state stream failed. */
    failed: boolean;
    /** Explicitly opened account dialog outside onboarding. */
    loginVisible?: boolean;
    /** Latest explicit start request failed before a Host state was available. */
    loginFailed?: boolean;
    /** Mounted onboarding owns the dialog while active. */
    onboarding?: boolean;
}
/** Host operations injected into the Cordis-free account component. */
export interface AccountSectionInjected {
    /** Desktop-only commands; absent in ordinary browsers. */
    platform?: PlatformBridge;
    /** Account stream owned by the Host and theme snapshots published by the renderer, observed through framework hooks. */
    hooks: {
        account: HostObservable<AccountSnapshot>;
        /** Palette the Platform login pages follow. */
        theme: HostObservable<ThemeSnapshot>;
    };
    /** @returns after account details are refreshed; concurrent refreshes share a request. */
    refresh: () => Promise<void>;
    /** Open the external support questionnaire with the current build and browser environment. */
    contactUs: () => void;
    /** Open or dismiss the login dialog. */
    showLogin: (visible: boolean) => void;
    /** Claim dialog ownership for the onboarding step. */
    setOnboarding: (active: boolean) => void;
    /** @returns after the login attempt is created. */
    start: () => Promise<void>;
    /** @param id - attempt to cancel. @returns after cancellation or an already-admitted commit. */
    cancel: (id: SignInAttemptId) => Promise<void>;
    /** @returns after local account credentials are removed. */
    signOut: () => Promise<void>;
}
/** Composed account section props. */
export type AccountSectionProps = PropsRuntime<'settings.section'> & PropsLocale<'settings.account'> & InjectFace<AccountSectionInjected>;
/** @param props - localized actions and account subscription. @returns account settings UI. */
export declare function AccountSection({ t, useAccount, useTheme, start, cancel, refresh, platform }: AccountSectionProps): import("react").JSX.Element;
//# sourceMappingURL=AccountSection.d.ts.map