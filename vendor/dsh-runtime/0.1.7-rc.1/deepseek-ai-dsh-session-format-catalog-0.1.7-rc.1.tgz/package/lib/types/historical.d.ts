/** Historical restoration for collecting migration prerequisites without recursively opening current Sessions. */
/** V0–V3 decoding for historical child identity; never publishes or completes parent catalogs. */
export declare const historicalSessionFormatCatalog: import("@deepseek-ai/dsh-session-format").SessionFormatCatalog;
//# sourceMappingURL=historical.d.ts.map