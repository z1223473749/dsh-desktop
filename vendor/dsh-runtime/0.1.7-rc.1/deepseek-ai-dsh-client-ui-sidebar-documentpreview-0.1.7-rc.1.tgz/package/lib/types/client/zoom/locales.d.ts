/** Shared zoom copy embedded into renderer-owned dictionaries. */
export declare const zoomZh: {
    readonly zoomControls: "缩放控件";
    readonly zoomMenu: "选择缩放比例";
    readonly zoomOut: "缩小";
    readonly zoomIn: "放大";
    readonly zoomFitWidth: "适应宽度";
    readonly zoomValue: "{percent}%";
};
/** Shared English zoom copy. */
export declare const zoomEn: {
    zoomControls: string;
    zoomMenu: string;
    zoomOut: string;
    zoomIn: string;
    zoomFitWidth: string;
    zoomValue: string;
};
/** Shared zoom dictionary keys. */
export type ZoomLocaleKey = keyof typeof zoomZh;
//# sourceMappingURL=locales.d.ts.map