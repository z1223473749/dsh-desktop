import { Context, Service } from '@deepseek-ai/cordis';
import Schema from '@deepseek-ai/schemastery';
import { DeepSeekAccount, type PlatformSession, type AccountDetails, type AccountView, type SignInAttemptId } from '@deepseek-ai/dsh-deepseek-account';
/** Deployment-specific platform and request deadlines. */
export interface Config {
    /** Platform origin serving auth-api and browser pages. */
    platformOrigin?: string;
    /** Native desktop identity for Host API and embedded Platform requests; null identifies the client as web. */
    desktopPlatform?: 'darwin' | 'win32' | null;
    /** Optional frontend deployment selector for embedded Usage and Top-up pages. */
    embeddedPageDist?: string;
    /** Exact HTTP(S) origin allowed to receive account tokens for inference and files. */
    inferenceOrigin?: string;
    /** Allow HTTP only on loopback for the development Mock. */
    allowLoopbackHttp?: boolean;
    /** Map authorization and completion pages to platformOrigin for private development proxies. */
    rewriteBrowserOrigin?: boolean;
    /** Host-only headers sent exclusively to platformOrigin; account authorization cannot be overridden. */
    requestHeaders?: Record<string, string>;
    /** Overrides for profile, balance and embedded Platform requests; Cookie pairs merge by name. Logout retains requestHeaders. */
    accountRequestHeaders?: Record<string, string>;
    /** Deadline for each platform HTTP request. */
    requestTimeoutMs?: number;
    /** Additional logout attempts after the first request fails, at most five. */
    logoutMaxRetries?: number;
    /** Delay before the first logout retry; each later delay doubles. */
    logoutRetryDelayMs?: number;
    /** Upper bound for the entire local attempt, even if the server advertises a longer TTL. */
    attemptTimeoutMs?: number;
}
/** Validated deployment choices. */
export declare const Config: Schema<Schemastery.ObjectS<NoInfer<{
    platformOrigin: Schema<string, string, "defined">;
    desktopPlatform: Schema<"darwin" | "win32" | null, "darwin" | "win32" | null, "defined">;
    embeddedPageDist: Schema<string, string, "defined">;
    inferenceOrigin: Schema<string, string, "defined">;
    allowLoopbackHttp: Schema<boolean, boolean, "defined">;
    rewriteBrowserOrigin: Schema<boolean, boolean, "defined">;
    requestHeaders: Schema<import("@deepseek-ai/cosmokit").Dict<string, string>, import("@deepseek-ai/cosmokit").Dict<string, string>, "defined">;
    accountRequestHeaders: Schema<import("@deepseek-ai/cosmokit").Dict<string, string>, import("@deepseek-ai/cosmokit").Dict<string, string>, "defined">;
    requestTimeoutMs: Schema<number, number, "defined">;
    logoutMaxRetries: Schema<number, number, "defined">;
    logoutRetryDelayMs: Schema<number, number, "defined">;
    attemptTimeoutMs: Schema<number, number, "defined">;
}>>, Schemastery.ObjectT<NoInfer<{
    platformOrigin: Schema<string, string, "defined">;
    desktopPlatform: Schema<"darwin" | "win32" | null, "darwin" | "win32" | null, "defined">;
    embeddedPageDist: Schema<string, string, "defined">;
    inferenceOrigin: Schema<string, string, "defined">;
    allowLoopbackHttp: Schema<boolean, boolean, "defined">;
    rewriteBrowserOrigin: Schema<boolean, boolean, "defined">;
    requestHeaders: Schema<import("@deepseek-ai/cosmokit").Dict<string, string>, import("@deepseek-ai/cosmokit").Dict<string, string>, "defined">;
    accountRequestHeaders: Schema<import("@deepseek-ai/cosmokit").Dict<string, string>, import("@deepseek-ai/cosmokit").Dict<string, string>, "defined">;
    requestTimeoutMs: Schema<number, number, "defined">;
    logoutMaxRetries: Schema<number, number, "defined">;
    logoutRetryDelayMs: Schema<number, number, "defined">;
    attemptTimeoutMs: Schema<number, number, "defined">;
}>>, "plain">;
/** The platform implementation owns login state and its opaque stored grant. */
export declare class PlatformAccount extends DeepSeekAccount {
    static inject: string[];
    static Config: Schema<Schemastery.ObjectS<NoInfer<{
        platformOrigin: Schema<string, string, "defined">;
        desktopPlatform: Schema<"darwin" | "win32" | null, "darwin" | "win32" | null, "defined">;
        embeddedPageDist: Schema<string, string, "defined">;
        inferenceOrigin: Schema<string, string, "defined">;
        allowLoopbackHttp: Schema<boolean, boolean, "defined">;
        rewriteBrowserOrigin: Schema<boolean, boolean, "defined">;
        requestHeaders: Schema<import("@deepseek-ai/cosmokit").Dict<string, string>, import("@deepseek-ai/cosmokit").Dict<string, string>, "defined">;
        accountRequestHeaders: Schema<import("@deepseek-ai/cosmokit").Dict<string, string>, import("@deepseek-ai/cosmokit").Dict<string, string>, "defined">;
        requestTimeoutMs: Schema<number, number, "defined">;
        logoutMaxRetries: Schema<number, number, "defined">;
        logoutRetryDelayMs: Schema<number, number, "defined">;
        attemptTimeoutMs: Schema<number, number, "defined">;
    }>>, Schemastery.ObjectT<NoInfer<{
        platformOrigin: Schema<string, string, "defined">;
        desktopPlatform: Schema<"darwin" | "win32" | null, "darwin" | "win32" | null, "defined">;
        embeddedPageDist: Schema<string, string, "defined">;
        inferenceOrigin: Schema<string, string, "defined">;
        allowLoopbackHttp: Schema<boolean, boolean, "defined">;
        rewriteBrowserOrigin: Schema<boolean, boolean, "defined">;
        requestHeaders: Schema<import("@deepseek-ai/cosmokit").Dict<string, string>, import("@deepseek-ai/cosmokit").Dict<string, string>, "defined">;
        accountRequestHeaders: Schema<import("@deepseek-ai/cosmokit").Dict<string, string>, import("@deepseek-ai/cosmokit").Dict<string, string>, "defined">;
        requestTimeoutMs: Schema<number, number, "defined">;
        logoutMaxRetries: Schema<number, number, "defined">;
        logoutRetryDelayMs: Schema<number, number, "defined">;
        attemptTimeoutMs: Schema<number, number, "defined">;
    }>>, "plain">;
    private readonly origin;
    private readonly embeddedPageDist;
    private readonly inferenceOrigin;
    private readonly rewriteBrowserOrigin;
    private readonly clientHeaders;
    private readonly requestHeaders;
    private readonly accountRequestHeaders;
    private readonly requestTimeout;
    private readonly attemptTimeout;
    private readonly logoutPolicy;
    private readonly logoutLifetime;
    private readonly revocations;
    private attempt;
    private readonly listeners;
    private lastProfile;
    private detailsLifetime;
    private closed;
    private removing;
    /** @param ctx - Host with authorization and credentials services. @param config - deployment options. */
    constructor(ctx: Context, config?: Config);
    [Service.init](): Promise<void>;
    getState(): Promise<AccountView>;
    getProfile(): Promise<AccountDetails['profile'] | null>;
    getBalance(): Promise<AccountDetails['balance'] | null>;
    private getDetail;
    getPlatformSession(): Promise<PlatformSession | null>;
    private readCurrentGrant;
    resolveToken(url: string): Promise<string | undefined>;
    startSignIn(locale: string, callbackOrigin: string, loginSource: 'web' | 'desktop'): Promise<AccountView>;
    cancelSignIn(id: SignInAttemptId): Promise<AccountView>;
    signOut(): Promise<AccountView>;
    watch(signal: AbortSignal): AsyncIterable<AccountView>;
    private revoke;
    private invalidateDetails;
    private changed;
    private update;
    private run;
    private rejectPayload;
    private cancelRequest;
    private request;
    private finishFailedCallback;
}
export default PlatformAccount;
//# sourceMappingURL=index.d.ts.map