/**
 * Loop the tail every three seconds after a 0.3s delay.
 * @returns animated and resting contours switched by the reduced-motion stylesheet.
 */
export declare function RunningWhaleTail(): import("react").JSX.Element;
//# sourceMappingURL=RunningWhaleTail.d.ts.map