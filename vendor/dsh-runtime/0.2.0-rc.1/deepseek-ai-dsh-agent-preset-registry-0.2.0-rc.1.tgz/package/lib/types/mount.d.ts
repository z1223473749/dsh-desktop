/** Runtime plugin trees shared by Agents selecting one preset revision. */
import { Context, type Fiber } from '@deepseek-ai/cordis';
import { EntryTree } from '@deepseek-ai/cordis-plugin-loader';
import type { PresetDefinition } from './definition.ts';
import { type ScopeKey } from '@deepseek-ai/dsh-scope';
/** One live revision shared by Agents and scoped readers. */
export interface PresetMount {
    /** The preset the subtree was composed from. */
    readonly presetId: string;
    /** The mounted subtree's fiber. */
    readonly fiber: Fiber;
    /** Loader entry tree whose active rows form this standing composition. */
    readonly tree: EntryTree;
    /** The standing scope key agents are parented to (undefined only in torn-down records). */
    readonly key: ScopeKey | undefined;
}
/**
 * Every preset composition retained by the registry.
 *
 * The record set is module state and therefore spans every Cordis runtime in
 * the process; a reader that serves one runtime passes that runtime's root
 * fiber so another runtime mounting the same preset id (a second embedded
 * app, a test's second harness) never answers for it.
 * @param within - when present, only mounts inside this fiber's subtree.
 * @returns the live mounts.
 */
export declare function livePresetMounts(within?: Fiber): PresetMount[];
/**
 * Service names the mounted subtree published into the root realm.
 *
 * A provider without an `isolate` realm stores its implementation under the
 * root's symbol for that name, which is exactly the comparison below; a
 * provider inside an `isolate` realm stores under a realm-private symbol and
 * is correctly absent here.
 * @param ctx - any context of the runtime whose service store is inspected.
 * @param mount - the mounted subtree's fiber.
 * @returns the leaked service names in lexical order.
 */
export declare function leakedServices(ctx: Context, mount: Fiber): string[];
/** A live standing mount located through one agent already joined to it. */
export type JoinedPresetMount = PresetMount & {
    /** The standing key, definite because it is what the lookup matched on. */
    readonly key: ScopeKey;
};
/**
 * The standing composition one agent is joined to.
 *
 * The agent's own key is parented to its preset's standing key, so the mount
 * is found by matching that parent rather than by walking up from the agent —
 * the mount is not under the agent's fiber. An agent that joined no preset —
 * a deployment composing no roster, or a child agent before its join — has no
 * parent link and resolves to undefined.
 * @param agentCtx - the agent's scope context.
 * @returns the mount the agent joined, or undefined when it joined none.
 */
export declare function standingMountFor(agentCtx: Context): JoinedPresetMount | undefined;
/**
 * One agent's instance of a service its preset mounted.
 *
 * Preset revisions publish services behind an `isolate` realm. Browser RPCs
 * hold the Agent but resolve outside that realm, so they locate its revision
 * through the Agent's scope parent.
 *
 * Ownership is the same relation {@link leakedServices} reads, inverted: there
 * it names implementations a subtree published into the ROOT realm, here it
 * names the one this subtree published anywhere. Fiber membership is object
 * identity for the reason stated on {@link withinFiber}.
 *
 * This is read addressing for a caller that already holds the agent. It is not
 * a general host handle on a session's internals: a host row that `inject`s a
 * service cannot use it, because injection resolves before any session exists
 * and has no agent to key by — such a service belongs on the host plane.
 * @param ctx - any context of the runtime whose service store is inspected.
 * @param agent - the agent whose mounted composition to look inside.
 * @param name - the service name as the preset's rows resolve it.
 * @returns the agent's instance, or undefined when its preset mounts none.
 */
export declare function serviceForAgent<K extends string & keyof Context>(ctx: Context, agent: {
    ctx: Context;
}, name: K): Context[K] | undefined;
/** Rows that did not reach a usable state, each rendered as one diagnostic line. */
export interface RowAudit {
    /** Rows that never started or whose import or activation rejected. */
    readonly failed: string[];
    /**
     * Rows waiting for a service the composition does not supply. A Host
     * provider still activating completes such a row later; only a settled Host
     * tree tells that case from a genuinely missing service.
     */
    readonly pending: string[];
}
/**
 * Audit the rows of a mounted subtree.
 *
 * Wait for the subtree, then report import failures, activation failures, and
 * rows waiting for services the composition does not supply.
 * @param tree - the mounted subtree.
 * @returns failed and pending rows, both empty when every enabled row is usable.
 */
export declare function auditRows(tree: EntryTree): Promise<RowAudit>;
/** Load and audit one revision under its registry-owned scope.
 *
 * Failed rows and root-realm service leaks reject the mount. Rows waiting for
 * a Host service stay mounted: they activate by themselves once the provider
 * finishes, and the registry re-audits them after the Host tree settles.
 * Inside a profile, compatibility policy decides admission first: a row whose
 * plugin the profile denies mounts disabled, so the audit reads it as
 * intentionally inactive instead of reporting a failed import.
 * @param ctx Scope context inheriting the declaring Loader's resolution base.
 * @param id Preset identity.
 * @param plugins Declared Cordis entry list.
 * @returns The live tree; scope disposal owns its teardown.
 */
export declare function mountPreset(ctx: Context, id: string, plugins: PresetDefinition['plugins']): Promise<PresetMount>;
//# sourceMappingURL=mount.d.ts.map