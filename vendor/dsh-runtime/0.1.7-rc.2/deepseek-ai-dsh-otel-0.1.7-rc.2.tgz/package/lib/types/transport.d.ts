import { type OTLPExporterNodeConfigBase } from '@opentelemetry/otlp-exporter-base';
import type { LogRecordExporter } from '@opentelemetry/sdk-logs';
/**
 * Create an SDK JSON exporter without inheriting another collector's headers or TLS identity.
 * @param options - explicit endpoint, headers, agent, and SDK transport settings.
 * @returns the exporter owned by one independent log pipeline.
 */
export declare function createLogExporter(options: OTLPExporterNodeConfigBase & {
    url: string;
}): LogRecordExporter;
//# sourceMappingURL=transport.d.ts.map