/**
 * Display copy for the tree's copy affordance; the owner passes localized
 * labels (this package is cordis-free, so copy arrives via props).
 */
export interface JsonTreeLabels {
    /** Menu item: copy the raw primitive value. */
    copyValue: string;
    /** Menu item: copy the value as compact JSON (primitive rows). */
    copyJson: string;
    /** Menu item: copy the property path. */
    copyPath: string;
    /** Menu item: copy the value as pretty-printed JSON. */
    copyPrettyJson: string;
    /** Menu item: copy the value as compact JSON (object rows). */
    copyCompactJson: string;
    /** Copy-button state label after a successful copy. */
    copied: string;
    /** Copy-button state label after a failed copy. */
    copyFailed: string;
    /** Expander aria label while expanded. */
    collapseNode: string;
    /** Expander aria label while collapsed. */
    expandNode: string;
    /** Copy-button tooltip, given the current action label. */
    copyButtonTitle: (action: string) => string;
}
/** Props for the read-only, token-themed JSON tree. */
export interface JsonTreeProps {
    /** Parsed JSON object or array. */
    data: object | unknown[];
    /** Accessible label for the tree. */
    label: string;
    /** Optional positioning class owned by the caller. */
    className?: string | undefined;
    /** Maximum visible lines per collapsed string; defaults to 3. */
    collapsedStringLines?: number;
    /** Optional wrap toggle; each expansion reads the shared default without changing other open strings. */
    stringWrapping?: {
        /** Localized label for the wrapping toggle. */
        label: string;
        /** Read the wrapping preference when a string is expanded. @returns Whether to wrap long lines. */
        getDefault: () => boolean;
        /** Remember a user toggle for future expansions. @param wrapped - Whether to wrap long lines. */
        setDefault: (wrapped: boolean) => void;
    } | undefined;
    /** Whether JSON rows expose copy actions. */
    copyable?: boolean;
    /** Whether the top-level object or array is always expanded. */
    expandTopLevel?: boolean;
    /** Localized display copy supplied by the owning render site. */
    labels: JsonTreeLabels;
}
/**
 * Render parsed JSON as a compact, keyboard-accessible inspector tree.
 * @param props - Parsed data, accessible label, and display options.
 * @returns A read-only JSON tree with an optionally fixed-open top level.
 */
export declare function JsonTree({ data, label, className, collapsedStringLines, stringWrapping, copyable, expandTopLevel, labels, }: JsonTreeProps): import("react").JSX.Element;
//# sourceMappingURL=JsonTree.d.ts.map