/**
 * The paged read this type performs, bound to the Client Remote.
 *
 * Content is the consumer's business: the `file` resource carries metadata only,
 * and the text arrives here one page of lines at a time. The endpoint takes a
 * session and a workspace path while a tab carries a `dsh-resource://file/`
 * session address, so this module also owns that translation.
 */
import type { RemoteResult } from '@deepseek-ai/dsh-api-remotes/client';
import type { SessionId } from '@deepseek-ai/dsh-session/types';
import type { WorkspaceFileBytes, WorkspaceFileRange, WorkspaceFileText } from '@deepseek-ai/dsh-api-workspace-files/types';
/** The slice of the Client Remote this package calls. */
export interface WorkspaceFilesReadRemote {
    readonly workspaceFiles: {
        /**
         * Read one page of lines.
         * @param sessionId - the session whose workspace resolves `path`.
         * @param path - workspace path, absolute or relative to the workspace root.
         * @param range - 1-based start line; the Host's page cap applies when `limit` is absent.
         * @param signal - cancels the call.
         * @returns the page, or the failure the Host declares.
         */
        read(sessionId: SessionId, path: string, range: WorkspaceFileRange, signal?: AbortSignal): Promise<RemoteResult<WorkspaceFileText>>;
    };
}
/**
 * The read one page performs, injected so the face stays host-free.
 *
 * The session travels with the call because the endpoint resolves the workspace
 * root from it: the same path means different files in different sessions. A
 * Remote call does not reject: the result carries the failure.
 */
export type ReadWorkspaceFilePage = (sessionId: SessionId, path: string, offset: number, signal: AbortSignal) => Promise<RemoteResult<WorkspaceFileText>>;
/** The file one tab reads: the session the read runs under and the path handed to the Host. */
export interface SessionFile {
    /** The Session whose workspace resolves relative paths. */
    readonly sessionId: SessionId;
    /** The path the Host receives, absolute or relative to the addressed Session's workspace. */
    readonly path: string;
}
/**
 * The session and path one `dsh-resource://file/…` address names.
 *
 * A `session` address names its own session and a relative or absolute path, so
 * a tab addressed into another session reads from that session. An `absolute`
 * address carries no session and cannot be read here. The registry routes only
 * session-scoped `file` addresses to this type, so an address `parseFileAddress`
 * rejects or that carries no session is a programming error and throws.
 * @param address - a tab's `dsh-resource://file/…` address.
 * @returns the session and the path to hand the endpoint.
 */
export declare function hostFileOf(address: string): SessionFile;
/**
 * Bind the paged read to one Remote face. The page length is the Host's
 * configured cap, so no `limit` travels.
 * @param remote - the Client Remote carrying the `workspaceFiles` namespace.
 * @returns the read the face performs.
 */
export declare function createReadPage(remote: WorkspaceFilesReadRemote): ReadWorkspaceFilePage;
/** Document bytes borrowed read-only by renderers; copy before transferring to a Worker. */
export type DocumentFileBytes = WorkspaceFileBytes<Uint8Array<ArrayBuffer>>;
/**
 * Read a complete file through the Host endpoint.
 * @param file - Session and path decoded from the tab address.
 * @param signal - owning tab lifetime.
 * @returns complete native bytes, including declared failures.
 */
export type ReadDocumentBytes = (file: SessionFile, signal: AbortSignal) => Promise<RemoteResult<DocumentFileBytes>>;
//# sourceMappingURL=rpc.d.ts.map